#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pthread.h"
#include "linked_list.h"

// sequence counter
int seq_ctr = 0;

//Read the file on a line by line basis
char* read_line(char* fname, int line_no) 
{
	// TODO 
} 

//traverse the linked list
void traversal(node *head)
{
	// TODO
}

// insert the node into the linked list
void insert(node **phead, node *newnode)
{
	// TODO
}

//create a new node structure
node* create_node(int line_no, char *line)
{
	// TODO
}
